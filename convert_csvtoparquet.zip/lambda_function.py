import json
import pandas as pd
import boto3
import awswrangler as wr
s3_client = boto3.client('s3')
def lambda_handler(event, context):
    try:            
        df = wr.s3.read_csv(path='s3://iata-farman/raw/2m Sales Records.csv')

        # This 'magic' needs s3fs (https://pypi.org/project/s3fs/)
        #df=pd.read_csv(f's3://{bucket_name}/{s3_file_name}', sep=',')
        wr.s3.to_parquet(df, path='s3://iata-farman/partitioned/',dataset=True,partition_cols=['Country'],mode='overwrite')

    except Exception as err:
        print(err)
import boto3
import requests
from zipfile import ZipFile
import zipfile
import io
def uncompress(bucket,key,s3):
    try:
        obj = s3.get_object(Bucket=bucket, Key=key)
        putObjects = []
        with io.BytesIO(obj["Body"].read()) as tf:
            # rewind the file
            tf.seek(0)

            # Read the file as a zipfile and process the members
            with zipfile.ZipFile(tf, mode='r') as zipf:
                for file in zipf.infolist():
                    fileName = file.filename
                    putFile = s3.put_object(Bucket=bucket, Key='raw/'+fileName, Body=zipf.read(file))
                    putObjects.append(putFile)
                    print(putFile)


        # Delete zip file after unzip
        if len(putObjects) > 0:
            deletedObj = s3.delete_object(Bucket=bucket, Key=key)
            print('deleted file:')
            print(deletedObj)

    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise
def lambda_handler(event, context):

    url='https://eforexcel.com/wp/wp-content/uploads/2020/09/2m-Sales-Records.zip' # put your url here
    bucket = 'iata-farman' #your s3 bucket
    key = 'raw/2m-Sales-Records.zip' #your desired s3 path or filename
    headers = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:60.0) Gecko/20100101 Firefox/60.0"
    	
    }
    s3=boto3.client('s3')
    data = requests.get(url, headers=headers).content
    s3.upload_fileobj(io.BytesIO(data), bucket, key)
    uncompress(bucket,key,s3)
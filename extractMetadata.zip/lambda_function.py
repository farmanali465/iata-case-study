import json
import boto3
    
print('Loading function')
glue = boto3.client(service_name='glue')
def lambda_handler(event, context):
    try:
        glue.start_crawler(Name='iata-case-study')
    except Exception as e:
        print(e)
        print('Error starting crawler')
        raise e